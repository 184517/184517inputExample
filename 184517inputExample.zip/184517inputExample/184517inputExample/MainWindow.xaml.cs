﻿/*
 * Jordan Ross
 * February 11, 2019
 * Playing with Properties 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184517inputExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MessageBox.Show("Here is my message");
        }

        private void txtBox_GotFocus(object sender, RoutedEventArgs e)
        {
            txtBox.Background = Brushes.Purple;
        }

        private void txtBox_LostFocus(object sender, RoutedEventArgs e)
        {
            txtBox.Background = Brushes.AliceBlue;
        }

        private void calStartDate_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            DateTime date = (DateTime)calStartDate.SelectedDate;
            MessageBox.Show(date.ToString());
        }
    }
}
